
export function Button({ children, onClick }) {
  return (
    <button onClick={onClick} className="bg-gray-700 hover:bg-gray-600 text-white py-1 px-3 rounded">
      {children}
    </button>
  );
}
