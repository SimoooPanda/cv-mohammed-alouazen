
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function CVSite() {
  const [lang, setLang] = useState("fr");

  const content = {
    fr: {
      name: "Mohammed Alouazen",
      title: "Directeur Qualité & Ingénierie",
      about:
        "Directeur expérimenté dans le domaine de la qualité et de l'ingénierie, spécialisé dans l'industrie électronique. Expertise en audits, amélioration continue, et gestion des équipes multidisciplinaires.",
      experience: [
        {
          role: "Directeur Qualité et Ingénierie",
          company: "Synapse Électronique",
          years: "2023 - Aujourd'hui",
          details: "Responsable de la qualité et de l'ingénierie pour une usine de thermostats. Gestion des audits (ISO 9001), optimisation des procédés, pilotage de projets industriels."
        },
        {
          role: "Gestionnaire de programmes",
          company: "BRP Megatech",
          years: "2023 - 2024",
          details: "Suivi de programmes manufacturiers, coordination interfonctionnelle."
        }
      ],
      contact: "Contactez-moi à m.alouazen@gmail.com ou via LinkedIn."
    },
    en: {
      name: "Mohammed Alouazen",
      title: "Director of Quality & Engineering",
      about:
        "Experienced director in quality and engineering within the electronics industry. Specialized in audits, continuous improvement, and cross-functional team leadership.",
      experience: [
        {
          role: "Director of Quality and Engineering",
          company: "Synapse Électronique",
          years: "2023 - Present",
          details: "In charge of quality and engineering at a thermostat manufacturing plant. Oversaw ISO 9001 audits, process optimization, and industrial project management."
        },
        {
          role: "Program Manager",
          company: "BRP Megatech",
          years: "2023 - 2024",
          details: "Managed manufacturing programs, coordinated cross-functional teams."
        }
      ],
      contact: "Contact me at m.alouazen@gmail.com or via LinkedIn."
    },
    ar: {
      name: "محمد العوازن",
      title: "مدير الجودة والهندسة",
      about:
        "مدير ذو خبرة في مجالي الجودة والهندسة في صناعة الإلكترونيات. متخصص في التدقيق، والتحسين المستمر، وإدارة الفرق المتعددة التخصصات.",
      experience: [
        {
          role: "مدير الجودة والهندسة",
          company: "Synapse Électronique",
          years: "2023 - الآن",
          details: "مسؤول عن الجودة والهندسة في مصنع منظمات الحرارة. إدارة تدقيقات ISO 9001، وتحسين العمليات، وقيادة المشاريع الصناعية."
        },
        {
          role: "مدير برامج",
          company: "BRP Megatech",
          years: "2023 - 2024",
          details: "إدارة برامج التصنيع والتنسيق بين الفرق."
        }
      ],
      contact: "للتواصل: m.alouazen@gmail.com أو عبر لينكدإن."
    }
  };

  const c = content[lang];

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">{c.name}</h1>
          <p className="text-xl text-gray-400">{c.title}</p>
        </div>
        <div className="space-x-2">
          <Button onClick={() => setLang("fr")}>FR</Button>
          <Button onClick={() => setLang("en")}>EN</Button>
          <Button onClick={() => setLang("ar")}>AR</Button>
        </div>
      </header>

      <section className="mt-8">
        <h2 className="text-2xl font-semibold mb-2">{lang === "fr" ? "À propos" : lang === "en" ? "About" : "نبذة"}</h2>
        <p className="text-gray-300">{c.about}</p>
      </section>

      <section className="mt-8">
        <h2 className="text-2xl font-semibold mb-2">{lang === "fr" ? "Expérience" : lang === "en" ? "Experience" : "الخبرات"}</h2>
        <ul className="space-y-4">
          {c.experience.map((job, i) => (
            <li key={i} className="bg-gray-800 p-4 rounded-xl">
              <h3 className="text-xl font-bold">{job.role}</h3>
              <p className="text-sm text-gray-400">{job.company} | {job.years}</p>
              <p className="mt-2 text-gray-300">{job.details}</p>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-8">
        <h2 className="text-2xl font-semibold mb-2">{lang === "fr" ? "Contact" : lang === "en" ? "Contact" : "التواصل"}</h2>
        <p className="text-gray-300">{c.contact}</p>
      </section>
    </div>
  );
}
